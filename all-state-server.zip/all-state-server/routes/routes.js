import express, { response } from "express";
import nodemailer from "nodemailer";
import multer from "multer";
import * as dotenv from "dotenv";
dotenv.config();

const router = express.Router();

const upload = multer({
  dest: "uploads/",
  fileFilter: (req, file, cb) => {
    const allowedFileTypes = [".pdf", ".doc", ".docx"];
    const ext = file.originalname
      .substring(file.originalname.lastIndexOf("."))
      .toLowerCase();
    if (allowedFileTypes.includes(ext)) {
      cb(null, true);
    } else {
      cb(
        new Error(
          "Invalid file type. Only PDF, DOC, and DOCX files are allowed."
        )
      );
    }
  },
});

// Create a Nodemailer transporter using your preferred email service
const transporter = nodemailer.createTransport({
  service: "Outlook", // Change this to your preferred email service (e.g., 'Outlook', 'Yahoo', etc.)
  auth: {
    user: process.env.from_email, // Your email address
    pass: process.env.email_pass, // Your email password or app password (for Gmail, generate app password)
  },
});

// Function to send an email
const sendEmail = (email, lname, fname, role, phone, attachmentPath) => {
  let formattedContent = `
  <p>An job applications has been submitted through the company website</p>
  <p>Position: <strong>${role}</strong></p>
  <p>Phone Number: <strong>${phone}</strong></p>
  <p>Email: <strong>${email}</strong></p>
  <p>Full Name: <strong>${fname} ${lname}</strong></p>
  `;

  const mailOptions = {
    from: process.env.from_email,
    to: process.env.to_email,
    subject: "Job Application",
    html: formattedContent,
  };

  if (attachmentPath) {
    mailOptions.attachments = [
      {
        filename: "document.pdf", // The name you want the attachment to have in the email
        path: attachmentPath, // Path to the PDF file you want to attach
      },
    ];
  }

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.log("Error occurred:");
      console.log(error.message);
    } else {
      console.log("Email sent successfully!");
      console.log("Message ID: ", info.messageId);
    }
  });
};

router.post("/application", upload.single("file"), (req, res) => {
  const { email, fname, lname, role, phone } = req.body;

  if (!email || !fname || !lname || !role || !phone) {
    return res.status(400).json({ error: "Missing required fields" });
  }

  const attachmentPath = req.file ? req.file.path : null;
  sendEmail(email, lname, fname, role, phone, attachmentPath);
  res.json({ message: "Email sent successfully!" });
});

router.post("/merch", (req, res) => {
  const { data } = req.body;

  // Function to format an item's content
  function formatItemContent(item) {
    return `
    <div>
      <p><strong>Title:</strong> ${item.title}</p>
      <p><strong>Selected Size:</strong> ${item.selectedSize}</p>
      <p><strong>Price:</strong> ${item.price[item.selectedSize]}</p>
      <p><strong>Color:</strong> ${item.color}</p>
      <p><strong>Quantity:</strong> ${item.quantity}</p>
    </div>
    <hr />
  `;
  }

  let formattedContent = `
  <p>An employee has submitted a merch order!</p>
  <br />
  <p><strong>Employee ID:</strong> ${data.employeeId}</p>
  <hr />
  `;

  data.items.forEach((item) => {
    formattedContent += formatItemContent(item);
  });

  const mailOptions = {
    from: process.env.from_email,
    to: process.env.to_email,
    subject: `Merch Submission`,
    html: formattedContent,
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error("////////// Error: ", error);
      res.status(500).send("Error sending email");
    } else {
      console.log("Email sent: " + info.response);
      res.status(200).send("Email sent successfully");
    }
  });
  res.json({ message: "Merch order placed!" });
});

export default router;
